import { createActor } from "@/backend";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useActor } from "@caffeineai/core-infrastructure";
import {
  CheckCircle,
  Eye,
  EyeOff,
  Key,
  Loader2,
  Settings,
  ShieldCheck,
  TriangleAlert,
} from "lucide-react";
import { motion } from "motion/react";
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";

export default function SettingsPage() {
  const { actor, isFetching } = useActor(createActor);
  const [apiKey, setApiKey] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isCheckingStatus, setIsCheckingStatus] = useState(false);
  const [keyConfigured, setKeyConfigured] = useState<boolean | null>(null);

  const checkKeyStatus = useCallback(async () => {
    if (!actor) return;
    setIsCheckingStatus(true);
    try {
      const configured: boolean = await actor.getGroqApiKeyStatus();
      setKeyConfigured(configured);
    } catch {
      setKeyConfigured(false);
    } finally {
      setIsCheckingStatus(false);
    }
  }, [actor]);

  useEffect(() => {
    if (actor && !isFetching) {
      checkKeyStatus();
    }
  }, [actor, isFetching, checkKeyStatus]);

  async function handleSave() {
    if (!actor) return;
    if (!apiKey.trim()) {
      toast.error("Please enter an API key before saving.");
      return;
    }
    setIsSaving(true);
    try {
      await actor.setGroqApiKey(apiKey.trim());
      setApiKey("");
      await checkKeyStatus();
      toast.success("API key saved successfully.");
    } catch (err) {
      toast.error("Failed to save API key. Please try again.");
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  }

  const isLoading = isFetching || isCheckingStatus;

  return (
    <div className="min-h-screen px-8 py-12" data-ocid="settings.page">
      {/* Page header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="mb-10"
      >
        <div className="flex items-center gap-3 mb-2">
          <motion.div
            className="p-2 rounded-lg"
            style={{
              background:
                "linear-gradient(135deg, oklch(0.55 0.22 255 / 0.2), oklch(0.5 0.2 285 / 0.2))",
              border: "1px solid oklch(0.55 0.22 255 / 0.3)",
              boxShadow: "0 0 16px oklch(0.55 0.22 255 / 0.15)",
            }}
            animate={{
              boxShadow: [
                "0 0 16px oklch(0.55 0.22 255 / 0.15)",
                "0 0 28px oklch(0.55 0.22 255 / 0.3)",
                "0 0 16px oklch(0.55 0.22 255 / 0.15)",
              ],
            }}
            transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
          >
            <Settings size={20} className="text-primary" />
          </motion.div>
          <h1
            className="text-3xl font-display font-bold"
            style={{
              background:
                "linear-gradient(90deg, #e2e8f0 0%, #00d4ff 40%, #8b5cf6 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            Settings
          </h1>
        </div>
        <p className="text-sm text-muted-foreground ml-11">
          Configure your studio environment and AI integrations.
        </p>
      </motion.div>

      {/* AI Configuration Card */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, delay: 0.1, ease: "easeOut" }}
        className="max-w-2xl rounded-2xl p-6"
        style={{
          background:
            "linear-gradient(135deg, oklch(0.1 0.03 255 / 0.85), oklch(0.08 0.02 285 / 0.9))",
          backdropFilter: "blur(24px)",
          border: "1px solid oklch(0.55 0.22 255 / 0.18)",
          boxShadow:
            "0 8px 48px oklch(0 0 0 / 0.5), inset 0 1px 0 oklch(1 0 0 / 0.05)",
        }}
        data-ocid="settings.ai_config_card"
      >
        {/* Card header */}
        <div className="flex items-start justify-between mb-5">
          <div className="flex items-center gap-3">
            <div
              className="p-2 rounded-lg shrink-0"
              style={{
                background:
                  "linear-gradient(135deg, oklch(0.5 0.2 285 / 0.25), oklch(0.45 0.18 255 / 0.25))",
                border: "1px solid oklch(0.5 0.2 285 / 0.4)",
              }}
            >
              <Key size={16} className="text-secondary" />
            </div>
            <div>
              <h2 className="text-base font-display font-semibold text-foreground">
                AI Configuration
              </h2>
              <p className="text-xs text-muted-foreground mt-0.5">
                Power your studio with Groq's ultra-fast inference engine.
              </p>
            </div>
          </div>

          {/* Status badge */}
          {isLoading ? (
            <div
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs"
              style={{
                background: "oklch(0.55 0.22 255 / 0.1)",
                border: "1px solid oklch(0.55 0.22 255 / 0.2)",
              }}
              data-ocid="settings.status.loading_state"
            >
              <Loader2 size={11} className="text-primary animate-spin" />
              <span className="text-muted-foreground">Checking…</span>
            </div>
          ) : keyConfigured === true ? (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold"
              style={{
                background: "oklch(0.5 0.18 145 / 0.18)",
                border: "1px solid oklch(0.55 0.2 145 / 0.4)",
                color: "oklch(0.75 0.18 145)",
                boxShadow: "0 0 10px oklch(0.55 0.2 145 / 0.2)",
              }}
              data-ocid="settings.key_configured.success_state"
            >
              <CheckCircle size={11} />
              Key configured
            </motion.div>
          ) : keyConfigured === false ? (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold"
              style={{
                background: "oklch(0.6 0.18 60 / 0.18)",
                border: "1px solid oklch(0.65 0.2 60 / 0.4)",
                color: "oklch(0.78 0.18 60)",
                boxShadow: "0 0 10px oklch(0.65 0.2 60 / 0.15)",
              }}
              data-ocid="settings.key_not_configured.error_state"
            >
              <TriangleAlert size={11} />
              Not configured
            </motion.div>
          ) : null}
        </div>

        {/* Description */}
        <div
          className="flex items-start gap-2.5 mb-5 p-3 rounded-xl"
          style={{
            background: "oklch(0.55 0.22 255 / 0.06)",
            border: "1px solid oklch(0.55 0.22 255 / 0.1)",
          }}
        >
          <ShieldCheck size={15} className="text-primary shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground leading-relaxed">
            Your Groq API key is stored securely in the backend and used to
            power AI generation in the studio. It is never exposed to the
            browser or other users.
          </p>
        </div>

        {/* Input + save */}
        <div className="space-y-3">
          <label
            htmlFor="groq-api-key"
            className="block text-xs font-semibold text-foreground uppercase tracking-wider"
          >
            Groq API Key
          </label>
          <div className="relative">
            <input
              id="groq-api-key"
              type={showKey ? "text" : "password"}
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleSave();
              }}
              placeholder="gsk_••••••••••••••••••••••••••••••••"
              autoComplete="off"
              spellCheck={false}
              data-ocid="settings.api_key.input"
              className="w-full pr-10 pl-4 py-3 rounded-xl text-sm font-mono text-foreground placeholder:text-muted-foreground/50 transition-all duration-200 outline-none"
              style={{
                background: "oklch(0.08 0.02 255 / 0.8)",
                border: "1px solid oklch(0.55 0.22 255 / 0.25)",
                boxShadow: "inset 0 1px 3px oklch(0 0 0 / 0.3)",
              }}
              onFocus={(e) => {
                e.currentTarget.style.border =
                  "1px solid oklch(0.55 0.22 255 / 0.6)";
                e.currentTarget.style.boxShadow =
                  "0 0 0 2px oklch(0.55 0.22 255 / 0.12), inset 0 1px 3px oklch(0 0 0 / 0.3)";
              }}
              onBlur={(e) => {
                e.currentTarget.style.border =
                  "1px solid oklch(0.55 0.22 255 / 0.25)";
                e.currentTarget.style.boxShadow =
                  "inset 0 1px 3px oklch(0 0 0 / 0.3)";
              }}
            />
            <button
              type="button"
              onClick={() => setShowKey((v) => !v)}
              aria-label={showKey ? "Hide API key" : "Reveal API key"}
              data-ocid="settings.api_key_toggle"
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1 rounded"
            >
              {showKey ? <EyeOff size={15} /> : <Eye size={15} />}
            </button>
          </div>

          <motion.div
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            className="pt-1"
          >
            <Button
              type="button"
              disabled={isSaving || !apiKey.trim()}
              onClick={handleSave}
              data-ocid="settings.save_api_key.submit_button"
              className="w-full py-3 h-auto text-sm font-semibold rounded-xl transition-all duration-200"
              style={{
                background:
                  "linear-gradient(135deg, oklch(0.6 0.22 255), oklch(0.55 0.2 285))",
                boxShadow: "0 4px 20px oklch(0.6 0.22 255 / 0.35)",
                color: "oklch(1 0 0)",
              }}
            >
              {isSaving ? (
                <span className="flex items-center gap-2">
                  <Loader2 size={14} className="animate-spin" />
                  Saving…
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <Key size={14} />
                  Save API Key
                </span>
              )}
            </Button>
          </motion.div>
        </div>

        {/* Groq link hint */}
        <p className="mt-4 text-[11px] text-muted-foreground/60 text-center">
          Get your free key at{" "}
          <a
            href="https://console.groq.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-primary hover:text-primary/80 underline underline-offset-2 transition-colors"
          >
            console.groq.com
          </a>
        </p>
      </motion.div>
    </div>
  );
}
